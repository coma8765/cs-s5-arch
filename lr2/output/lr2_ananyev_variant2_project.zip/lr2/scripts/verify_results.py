"""Check observed end state, measured instruction schedules, and delivered traces."""
from pathlib import Path
import csv
import json

root = Path(__file__).resolve().parents[1]
analysis = json.loads((root / 'evidence/analysis.json').read_text())
for name, expected_cycles in [('test', 53), ('variant2', 56), ('variant2_opt', 56)]:
    rows = [{k: int(v, 16) for k, v in row.items()}
            for row in csv.DictReader((root / 'build' / name / 'cycles.csv').open())]
    result = next(row for row in rows if row['x31'] == sum(range(1, 9)) + 1)
    assert result['cycle'] == expected_cycles + 1, (name, result['cycle'])
    assert result['x20'] == 0, name
    assert result['x1'] == (0x80000060 if name == 'test' else 0x8000004c), name
    assert analysis[name]['cycles'] == expected_cycles, name
    assert (root / 'build' / name / 'trace.vcd').stat().st_size > 10000
    for item in analysis[name]['instructions']:
        if 'execute' in item:
            assert not item['discarded'], (name, item)
            assert item['execute'] <= item['complete'] <= expected_cycles
    print(name, 'PASS: x31=37, pointer/count, completion time, pipeline consistency')

def first(name, pc):
    return next(v for v in analysis[name]['instructions'] if v['pc'] == pc)

assert first('test', 0x80000010)['stages'] == {'5': 'F', '6': 'ID', '7': 'D', '8': 'C', '9': 'C', '10': 'AL'}
assert first('test', 0x8000001c)['execute'] == 15
assert first('test', 0x80000004)['execute'] == 5
assert first('variant2', 0x8000001c)['stages'] == {'8': 'F', '9': 'ID', '10': 'D', '11': 'AL'}
assert analysis['variant2']['raw_conflict_cycles'] == analysis['variant2_opt']['raw_conflict_cycles'] == 0
print('PASS: required instruction addresses and measured stage numbers')
