@echo off
vsim -do "do scripts/run.do ../src/variant2.hex"
