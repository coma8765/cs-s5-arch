onerror {quit -code 1 -force}
vsim -t 1ps -voptargs="+acc" work.tb -GHEX_FILE=../src/test.hex
log -r /*
run -all
quit -force
