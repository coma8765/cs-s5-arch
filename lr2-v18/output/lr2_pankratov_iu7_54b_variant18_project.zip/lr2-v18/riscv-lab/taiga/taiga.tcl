# Copyright (C) 2020  Intel Corporation. All rights reserved.
# Your use of Intel Corporation's design tools, logic functions 
# and other software and tools, and any partner logic 
# functions, and any output files from any of the foregoing 
# (including device programming or simulation files), and any 
# associated documentation or information are expressly subject 
# to the terms and conditions of the Intel Program License 
# Subscription Agreement, the Intel Quartus Prime License Agreement,
# the Intel FPGA IP License Agreement, or other applicable license
# agreement, including, without limitation, that your use is for
# the sole purpose of programming logic devices manufactured by
# Intel and sold by Intel or its authorized distributors.  Please
# refer to the applicable agreement for further details, at
# https://fpgasoftware.intel.com/eula.

# Quartus Prime: Generate Tcl File for Project
# File: taiga.tcl
# Generated on: Fri Oct 23 02:06:58 2020

# Load Quartus Prime Tcl Project package
package require ::quartus::project

set need_to_close_project 0
set make_assignments 1

# Check that the right project is open
if {[is_project_open]} {
	if {[string compare $quartus(project) "taiga"]} {
		puts "Project taiga is not open"
		set make_assignments 0
	}
} else {
	# Only open if not already open
	if {[project_exists taiga]} {
		project_open -revision taiga taiga
	} else {
		project_new -revision taiga taiga
	}
	set need_to_close_project 1
}

# Make assignments
if {$make_assignments} {
	set_global_assignment -name FAMILY "Cyclone V"
	set_global_assignment -name DEVICE 5CGXFC7C7F23C8
	set_global_assignment -name TOP_LEVEL_ENTITY taiga_wrapper
	set_global_assignment -name ORIGINAL_QUARTUS_VERSION 20.1.0
	set_global_assignment -name PROJECT_CREATION_TIME_DATE "02:14:15  SEPTEMBER 25, 2020"
	set_global_assignment -name LAST_QUARTUS_VERSION "20.1.0 Lite Edition"
	set_global_assignment -name PROJECT_OUTPUT_DIRECTORY output_files
	set_global_assignment -name ERROR_CHECK_FREQUENCY_DIVISOR 256
	set_global_assignment -name MIN_CORE_JUNCTION_TEMP 0
	set_global_assignment -name MAX_CORE_JUNCTION_TEMP 85
	set_global_assignment -name EDA_SIMULATION_TOOL "ModelSim-Altera (SystemVerilog)"
	set_global_assignment -name EDA_TIME_SCALE "1 ps" -section_id eda_simulation
	set_global_assignment -name EDA_OUTPUT_DATA_FORMAT "SYSTEMVERILOG HDL" -section_id eda_simulation
	set_global_assignment -name EDA_GENERATE_FUNCTIONAL_NETLIST OFF -section_id eda_board_design_timing
	set_global_assignment -name EDA_GENERATE_FUNCTIONAL_NETLIST OFF -section_id eda_board_design_symbol
	set_global_assignment -name EDA_GENERATE_FUNCTIONAL_NETLIST OFF -section_id eda_board_design_signal_integrity
	set_global_assignment -name EDA_GENERATE_FUNCTIONAL_NETLIST OFF -section_id eda_board_design_boundary_scan
	set_global_assignment -name POWER_PRESET_COOLING_SOLUTION "23 MM HEAT SINK WITH 200 LFPM AIRFLOW"
	set_global_assignment -name POWER_BOARD_THERMAL_MODEL "NONE (CONSERVATIVE)"
	set_global_assignment -name VERILOG_INPUT_VERSION SYSTEMVERILOG_2005
	set_global_assignment -name VERILOG_SHOW_LMF_MAPPING_MESSAGES OFF
	set_global_assignment -name PARTITION_NETLIST_TYPE SOURCE -section_id Top
	set_global_assignment -name PARTITION_FITTER_PRESERVATION_LEVEL PLACEMENT_AND_ROUTING -section_id Top
	set_global_assignment -name PARTITION_COLOR 16764057 -section_id Top
	set_global_assignment -name EDA_TEST_BENCH_ENABLE_STATUS TEST_BENCH_MODE -section_id eda_simulation
	set_global_assignment -name EDA_NATIVELINK_SIMULATION_TEST_BENCH tb -section_id eda_simulation
	set_global_assignment -name EDA_TEST_BENCH_NAME tb -section_id eda_simulation
	set_global_assignment -name EDA_DESIGN_INSTANCE_NAME uut -section_id tb
	set_global_assignment -name EDA_TEST_BENCH_RUN_SIM_FOR "10000 us" -section_id tb
	set_global_assignment -name EDA_TEST_BENCH_MODULE_NAME tb -section_id tb
	set_global_assignment -name EDA_TEST_BENCH_FILE my_tb/tb.sv -section_id tb
	set_global_assignment -name SEARCH_PATH lib
	set_global_assignment -name SYSTEMVERILOG_FILE lib/taiga_types.sv -library lib
	set_global_assignment -name SYSTEMVERILOG_FILE lib/taiga_config.sv -library taiga_config
	set_global_assignment -name SYSTEMVERILOG_FILE lib/riscv_types.sv -library lib
	set_global_assignment -name SYSTEMVERILOG_FILE core/put_get.sv
	set_global_assignment -name SYSTEMVERILOG_FILE examples/zedboard/taiga_wrapper.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/div_algorithms/div_radix2.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/div_algorithms/div_quick_clz.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/div_algorithms/div_algorithm.sv
	set_global_assignment -name SYSTEMVERILOG_FILE local_memory/local_memory_interface.sv
	set_global_assignment -name SYSTEMVERILOG_FILE local_memory/local_mem.sv
	set_global_assignment -name SYSTEMVERILOG_FILE l2_arbiter/l2_round_robin.sv
	set_global_assignment -name SYSTEMVERILOG_FILE l2_arbiter/l2_reservation_logic.sv
	set_global_assignment -name SYSTEMVERILOG_FILE l2_arbiter/l2_interfaces.sv
	set_global_assignment -name SYSTEMVERILOG_FILE l2_arbiter/l2_fifo.sv
	set_global_assignment -name SYSTEMVERILOG_FILE l2_arbiter/l2_external_interfaces.sv
	set_global_assignment -name SYSTEMVERILOG_FILE l2_arbiter/l2_config_and_types.sv
	set_global_assignment -name SYSTEMVERILOG_FILE l2_arbiter/l2_arbiter.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/intel/intel_byte_enable_ram.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/wishbone_master.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/toggle_memory.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/tlb_lut_ram.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/taiga_fifo.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/taiga.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/tag_bank.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/shift_counter.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/set_clr_reg_with_rst.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/register_file_and_writeback.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/register_file.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/regfile_bank_sel.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/reg_inuse.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/ras.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/placer_randomizer.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/one_hot_to_integer.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/one_hot_occupancy.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/mul_unit.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/mstatus_priv_reg.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/msb_naive.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/msb.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/mmu.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/lut_ram.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/load_store_unit.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/load_store_queue.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/l1_arbiter.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/itag_banks.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/interfaces.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/instruction_metadata_and_id_management.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/illegal_instruction_checker.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/id_inuse.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/icache.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/ibram.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/gc_unit.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/fetch.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/external_interfaces.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/dtag_banks.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/div_unit_core_wrapper.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/div_unit.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/decode_and_issue.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/ddata_bank.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/dcache.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/dbram.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/cycler.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/csr_types.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/csr_regs.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/clz.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/byte_en_BRAM.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/branch_unit.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/branch_predictor_ram.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/branch_predictor.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/branch_comparator.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/binary_occupancy.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/barrel_shifter.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/axi_to_arb.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/axi_master.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/avalon_master.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/amo_alu.sv
	set_global_assignment -name SYSTEMVERILOG_FILE core/alu_unit.sv
	set_global_assignment -name SYSTEMVERILOG_FILE my_tb/tb.sv
	set_instance_assignment -name PARTITION_HIERARCHY root_partition -to | -section_id Top

	# Commit assignments
	export_assignments

	# Close project
	if {$need_to_close_project} {
		project_close
	}
}
